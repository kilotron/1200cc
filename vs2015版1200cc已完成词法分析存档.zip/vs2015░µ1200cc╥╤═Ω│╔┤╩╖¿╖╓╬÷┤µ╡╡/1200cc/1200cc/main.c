#include "1200cc.h"

int main()
{
	lexer_init("test.c");
	lexer_demo();
	return 0;
}