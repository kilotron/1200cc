#include "1200cc.h"

extern SrcFile *src;

/* Pre-conditions: t != NULL, buf <= t->p < buf + file_size. */
void errorf(Token *t, char *fmt, ...)
{
	int line = 1;
	int col = 0;
	char *p;
	char *start = src->buf;	// beginning of the line

	// find out the line and col
	for (p = src->buf; p <= t->p; p++) {
		if (*p == '\n') {
			line++;
			col = 0;
			start = p + 1;
		}
		else {
			col++;
		}
	}

	fprintf(stderr, "%s:%d:%d: error: ", src->path, line, col);
	va_list va;
	va_start(va, fmt);
	vfprintf(stderr, fmt, va);
	va_end(va);

	// print out the line containing the error position.
	int len = strchr(start, '\n') - start;
	fprintf(stderr, "\n%.*s\n", len, start);
	for (int i = 0; i < col - 1; i++)
		fprintf(stderr, (start[i] == '\t') ? "\t" : " ");
	fprintf(stderr, "^\n");
}