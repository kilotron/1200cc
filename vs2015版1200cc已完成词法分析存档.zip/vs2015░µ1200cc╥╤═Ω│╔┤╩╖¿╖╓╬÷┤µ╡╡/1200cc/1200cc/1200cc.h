#pragma once
#include <stdlib.h>
#include <stdarg.h>
#include "util.h"

// Tokens

typedef struct {
	int type;		// type can have the value TK_ID, TK_NUM, etc.
	int value;		// Number literal or char literal
	char *lexeme;	// The name of an identifier or a keyword, string literal, etc.
	char *p;		// pointer to beginning of this token in source file
} Token;

enum {
	TK_BAD = 0,
	TK_LP = 40,		// Left parenthesis (
	TK_RP,			// Right parenthesis )
	TK_TIMES,		// *
	TK_PLUS,		// +
	TK_COMMA,		// ,
	TK_MINUS,		// -
	TK_DIV = 47,	// /
	TK_SC = 59,		// Semicolon ;
	TK_LS,			// <
	TK_ASSIGN,		// =
	TK_GT,			// >
	TK_LBRKT = 91,	// Left bracket [
	TK_RBRKT = 93,	// Right bracket ]
	TK_LBRACE = 123,// Left brace {
	TK_RBRACE = 125,// Right brace }

	TK_ID = 256,	// Identifier
	TK_CONST,		// Keyword 'const'
	TK_INT,
	TK_CHAR,
	TK_VOID,
	TK_MAIN,
	TK_IF,
	TK_ELSE,
	TK_WHILE,
	TK_FOR,
	TK_RETURN,
	TK_SCANF,
	TK_PRINTF,

	TK_NUML,		// Number literal
	TK_CHARL,		// Char literal
	TK_STRL,		// String literal

	TK_EQ,			// ==
	TK_NE,			// !=
	TK_GE,			// >=
	TK_LE,			// <=
	TK_EOF
};

void lexer_init(char *path);
Token *next_token();
void lexer_demo();

// error.c
void errorf(Token *t, char *fmt, ...);